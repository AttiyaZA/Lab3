
/*
    Programmer: Attiya Zahra
    Date: October 23, 2026
    Part 2
    Description: This program fixes syntax and logic errors in the Adventureland conversation. It asks the user for their name and responds using the name entered.
*/

#include <iostream>
#include <string>
using namespace std;

int main()
{
    string guideName;
    string userName;

    cout << "Welcome to Adventure Land. I am your guide...oh dear, "
        << "I've forgotten my name. What's my name?: ";
    cin >> guideName;

    cout << "Fantastic, I know my name now! It is "
        << guideName << "." << endl;

    cout << "But I'm being rude! What is your name?: ";
    cin >> userName;

    cout << "So your name is " << userName
        << ". What a splendid name!" << endl;

    return 0;
}


