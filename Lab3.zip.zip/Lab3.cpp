
/*
    Programmer: Attiya Zahra
    Date: October 23, 2026
    Description: This program asks the user for two integers, two double values, and a string. It calculates arithmetic operations for the numbers, finds the length of the string, and writes the program interaction and results to results.txt.
*/

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
    ofstream outFile("results.txt", ios::app);

    int int1, int2;
    int sumInt, differenceInt, productInt, quotientInt, modulusInt;

    double double1, double2;
    double sumDouble, differenceDouble, productDouble, quotientDouble;

    string userString;
    int stringLength;

    cout << "Welcome to Lab 3. You will need to enter two integers, "
        << "two real numbers, and a string. I will perform basic "
        << "arithmetic and tell you how long the string is." << endl;

    outFile << "Welcome to Lab 3. You will need to enter two integers, "
        << "two real numbers, and a string. I will perform basic "
        << "arithmetic and tell you how long the string is." << endl;

    cout << "Enter integer 1: ";
    outFile << "Enter integer 1: ";
    cin >> int1;
    outFile << int1 << endl;

    cout << "Enter integer 2: ";
    outFile << "Enter integer 2: ";
    cin >> int2;
    outFile << int2 << endl;

    cout << "Enter real number 1: ";
    outFile << "Enter real number 1: ";
    cin >> double1;
    outFile << double1 << endl;

    cout << "Enter real number 2: ";
    outFile << "Enter real number 2: ";
    cin >> double2;
    outFile << double2 << endl;

    cin.ignore(1000, '\n');

    cout << "Enter a string: ";
    outFile << "Enter a string: ";
    getline(cin, userString);
    outFile << userString << endl;

    sumInt = int1 + int2;
    differenceInt = int1 - int2;
    productInt = int1 * int2;

    if (int2 != 0)
    {
        quotientInt = int1 / int2;
        modulusInt = int1 % int2;
    }

    sumDouble = double1 + double2;
    differenceDouble = double1 - double2;
    productDouble = double1 * double2;

    if (double2 != 0)
    {
        quotientDouble = double1 / double2;
    }

    stringLength = userString.length();

    cout << int1 << " + " << int2 << " = " << sumInt << endl;
    outFile << int1 << " + " << int2 << " = " << sumInt << endl;

    cout << int1 << " - " << int2 << " = " << differenceInt << endl;
    outFile << int1 << " - " << int2 << " = " << differenceInt << endl;

    cout << int1 << " * " << int2 << " = " << productInt << endl;
    outFile << int1 << " * " << int2 << " = " << productInt << endl;

    if (int2 != 0)
    {
        cout << int1 << " / " << int2 << " = " << quotientInt << endl;
        outFile << int1 << " / " << int2 << " = " << quotientInt << endl;

        cout << int1 << " % " << int2 << " = " << modulusInt << endl;
        outFile << int1 << " % " << int2 << " = " << modulusInt << endl;
    }
    else
    {
        cout << "Cannot divide by zero." << endl;
        outFile << "Cannot divide by zero." << endl;
    }

    cout << double1 << " + " << double2 << " = " << sumDouble << endl;
    outFile << double1 << " + " << double2 << " = " << sumDouble << endl;

    cout << double1 << " - " << double2 << " = " << differenceDouble << endl;
    outFile << double1 << " - " << double2 << " = " << differenceDouble << endl;

    cout << double1 << " * " << double2 << " = " << productDouble << endl;
    outFile << double1 << " * " << double2 << " = " << productDouble << endl;

    if (double2 != 0)
    {
        cout << double1 << " / " << double2 << " = " << quotientDouble << endl;
        outFile << double1 << " / " << double2 << " = " << quotientDouble << endl;
    }
    else
    {
        cout << "Cannot divide by zero." << endl;
        outFile << "Cannot divide by zero." << endl;
    }

    cout << "\"" << userString << "\" has "
        << stringLength << " characters." << endl;

    outFile << "\"" << userString << "\" has "
        << stringLength << " characters." << endl;

    outFile.close();

    return 0;
}

